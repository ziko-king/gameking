package com.example.game2.helpers

enum class FieldConstants(val value: Int) {
    COLUMN_COUNT(10), ROW_COUNT(20)
}