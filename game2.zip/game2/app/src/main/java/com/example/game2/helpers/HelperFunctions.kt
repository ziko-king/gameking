package com.example.game2.helpers

fun array2dOfByte(sizeOuter:Int,sizeInner:Int):Array<ByteArray> = Array(sizeOuter) {ByteArray(sizeInner) }