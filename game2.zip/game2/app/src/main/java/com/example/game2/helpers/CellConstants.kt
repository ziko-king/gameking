package com.example.game2.helpers
enum class CellConstants(val value:Byte){
    EMPTY(0),EPHEMERAL(1)
}
